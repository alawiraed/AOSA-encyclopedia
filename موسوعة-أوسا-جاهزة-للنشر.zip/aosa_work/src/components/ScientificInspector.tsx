import React, { useState } from "react";
import {
  ArrowLeft,
  Camera,
  ChevronLeft,
  Cpu,
  Send,
  Wrench,
} from "lucide-react";
import {
  L200_ASSEMBLIES,
  SCIENTIFIC_PARTS,
  ScientificPart,
} from "../data/l200Data";

interface ScientificInspectorProps {
  selectedAssemblyId: string;
  selectedPartId: string;
  onSelectPart: (partId: string) => void;
  onGenerateImageForPart: (part: ScientificPart) => void;
}

export const ScientificInspector: React.FC<ScientificInspectorProps> = ({
  selectedAssemblyId,
  selectedPartId,
  onSelectPart,
  onGenerateImageForPart,
}) => {
  const assembly =
    L200_ASSEMBLIES.find((a) => a.id === selectedAssemblyId) ?? L200_ASSEMBLIES[0];
  const assemblyParts = SCIENTIFIC_PARTS.filter(
    (p) => p.assemblyId === assembly.id
  );
  const activePart =
    assemblyParts.find((p) => p.id === selectedPartId) ?? assemblyParts[0];

  const [question, setQuestion] = useState("");
  const [aiAnswer, setAiAnswer] = useState<string | null>(null);
  const [aiError, setAiError] = useState<string | null>(null);
  const [asking, setAsking] = useState(false);

  const handleAskEngineer = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!question.trim() || !activePart) return;
    setAsking(true);
    setAiError(null);
    try {
      const res = await fetch("/api/explain-part", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          partName: `${activePart.nameAr} (${activePart.nameEn})`,
          subsystem: assembly.nameAr,
          question: question.trim(),
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        setAiError(data.error ?? "تعذر الحصول على التحليل العلمي.");
      } else {
        setAiAnswer(data.answer);
      }
    } catch {
      setAiError("تعذر الاتصال بالخادم لإجراء التحليل العلمي.");
    } finally {
      setAsking(false);
    }
  };

  if (!activePart) return null;

  return (
    <aside className="flex flex-col h-full bg-[#111722] border border-white/10 rounded-xl overflow-hidden">
      {/* Assembly Header */}
      <div className="p-5 border-b border-white/8">
        <div className="flex items-center justify-between gap-3 text-xs text-slate-400 mb-1.5">
          <span>منظومة {assembly.indexLabel}</span>
          <span aria-hidden="true">·</span>
          <span className="font-mono-tech">{assembly.massEstimateKg} kg كتلة تقديرية</span>
        </div>
        <h2 className="text-lg font-bold text-white leading-snug">
          {assembly.nameAr}
        </h2>
        <p className="text-xs text-slate-400 mt-1.5 leading-relaxed">
          {assembly.summaryAr}
        </p>

        {/* Sub-component Selector Tabs */}
        <div className="flex flex-wrap gap-1.5 mt-4">
          {assemblyParts.map((part) => {
            const isActive = part.id === activePart.id;
            return (
              <button
                key={part.id}
                type="button"
                onClick={() => {
                  onSelectPart(part.id);
                  setAiAnswer(null);
                  setAiError(null);
                }}
                className={`px-2.5 py-1.5 rounded-md text-xs font-medium transition-colors border text-right ${
                  isActive
                    ? "bg-red-600/20 border-red-500/60 text-red-100"
                    : "bg-slate-900/60 border-white/8 text-slate-300 hover:text-white hover:border-white/20"
                }`}
              >
                {part.nameAr.split("(")[0].trim()}
              </button>
            );
          })}
        </div>
      </div>

      {/* Scrollable Scientific Breakdown */}
      <div className="flex-1 overflow-y-auto p-5 space-y-5">
        <div>
          <div className="flex items-center justify-between gap-2 text-xs text-slate-400 mb-1">
            <span className="font-mono-tech text-amber-400">{activePart.partCode}</span>
            <span dir="ltr" className="truncate text-slate-400">
              {activePart.nameEn}
            </span>
          </div>
          <h3 className="text-base font-bold text-white">{activePart.nameAr}</h3>
        </div>

        {/* Material & Operating Specs */}
        <div className="bg-[#0B0F14] border border-white/8 rounded-lg p-3.5 space-y-2 text-xs">
          <div>
            <span className="text-slate-400">المادة الهندسية والسبائك: </span>
            <span className="text-slate-100 font-medium">{activePart.material}</span>
          </div>
          <div className="pt-2 border-t border-white/6">
            <span className="text-slate-400">حدود التشغيل والقياس: </span>
            <span className="text-sky-300 font-mono-tech">{activePart.operatingSpecs}</span>
          </div>
        </div>

        {/* Scientific & Physical Principle */}
        <section className="space-y-2">
          <h4 className="text-xs font-semibold text-slate-300">
            التحليل الفيزيائي والمبدأ العلمي
          </h4>
          <p className="text-sm text-slate-200 leading-relaxed">
            {activePart.scientificPrinciple}
          </p>
        </section>

        {/* Governing Equation */}
        <section className="bg-[#0B0F14] border border-white/10 rounded-lg p-3.5 space-y-1.5">
          <div className="text-[11px] text-slate-400">المعادلة الحاكمة</div>
          <div
            dir="ltr"
            className="font-mono-tech text-xs sm:text-sm text-amber-300 overflow-x-auto py-1"
          >
            {activePart.equation}
          </div>
          <p className="text-[11px] text-slate-400 leading-relaxed">
            {activePart.equationLegend}
          </p>
        </section>

        {/* Mechanical Interaction & Failure Diagnostics */}
        <div className="space-y-3 text-xs leading-relaxed">
          <div className="pt-2 border-t border-white/8">
            <div className="font-semibold text-slate-200 mb-1 flex items-center gap-1.5">
              <ChevronLeft className="w-3.5 h-3.5 text-sky-400" />
              <span>التكامل الميكانيكي مع الأجزاء المجاورة</span>
            </div>
            <p className="text-slate-300">{activePart.mechanicalInteraction}</p>
          </div>

          <div className="pt-2 border-t border-white/8">
            <div className="font-semibold text-slate-200 mb-1 flex items-center gap-1.5">
              <Wrench className="w-3.5 h-3.5 text-red-400" />
              <span>التشخيص الهندسي والأعطال الشائعة</span>
            </div>
            <p className="text-slate-300">{activePart.failureDiagnostics}</p>
          </div>
        </div>

        {/* Action: Generate 1K/2K/4K Technical Image for This Component */}
        <button
          type="button"
          onClick={() => onGenerateImageForPart(activePart)}
          className="w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg bg-red-600 hover:bg-red-500 text-white text-xs font-semibold transition-colors"
        >
          <Camera className="w-4 h-4" />
          <span>توليد مخطط/صورة هندسية لهذه القطعة (1K · 2K · 4K)</span>
          <ArrowLeft className="w-3.5 h-3.5" />
        </button>

        {/* Deep Engineering Q&A */}
        <div className="pt-3 border-t border-white/10 space-y-2.5">
          <div className="flex items-center gap-1.5 text-xs font-semibold text-slate-200">
            <Cpu className="w-3.5 h-3.5 text-amber-400" />
            <span>استفسار هندسي متعمق حول هذه القطعة</span>
          </div>
          <form onSubmit={handleAskEngineer} className="flex gap-2">
            <input
              type="text"
              value={question}
              onChange={(e) => setQuestion(e.target.value)}
              placeholder="مثال: كيف يؤثر ضغط التوربو على كفاءة 4N15؟"
              className="flex-1 bg-[#0B0F14] border border-white/12 rounded-lg px-3 py-2 text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-red-500"
            />
            <button
              type="submit"
              disabled={asking || !question.trim()}
              className="px-3 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 disabled:opacity-50 text-white text-xs font-medium inline-flex items-center gap-1 shrink-0 transition-colors"
            >
              <Send className="w-3.5 h-3.5" />
              <span>{asking ? "تحليل..." : "اسأل"}</span>
            </button>
          </form>

          {aiError && (
            <div className="p-3 rounded-lg bg-red-950/50 border border-red-500/30 text-xs text-red-200">
              {aiError}
            </div>
          )}

          {aiAnswer && (
            <div className="p-3.5 rounded-lg bg-[#0B0F14] border border-white/10 text-xs text-slate-200 leading-relaxed whitespace-pre-wrap">
              {aiAnswer}
            </div>
          )}
        </div>
      </div>
    </aside>
  );
};
