import React, { useEffect, useState } from "react";
import { Download, Image as ImageIcon, Loader2, Sparkles } from "lucide-react";
import {
  GENERATED_GALLERY_IMAGES,
  SCIENTIFIC_PARTS,
  ScientificPart,
} from "../data/l200Data";

export type ImageResolution = "1K" | "2K" | "4K";
export type ImageAspect = "16:9" | "4:3" | "1:1";

interface GeneratedRecord {
  id: string;
  title: string;
  prompt: string;
  imageSize: ImageResolution;
  aspectRatio: ImageAspect;
  src: string;
  model: string;
  isStaticReference?: boolean;
}

interface ImageStudioProps {
  initialPart: ScientificPart | null;
}

const STYLE_MODIFIERS = [
  {
    id: "cutaway",
    label: "مقطع تشريحي هندسي (Cutaway CAD)",
    suffix:
      "Scientific isometric technical cutaway CAD illustration, exposed internal mechanical components, brushed titanium and machined steel surfaces, dark graphite studio background, precision rim lighting, no text labels.",
  },
  {
    id: "exploded",
    label: "رسم تفكيكي منفجر (Exploded View)",
    suffix:
      "Ultra-detailed exploded mechanical CAD assembly rendering with floating aligned fasteners, gears, and housings along assembly axes, dark industrial studio background, sharp metallic reflections, no text.",
  },
  {
    id: "studio",
    label: "تصوير استوديو مخبري (Macro Studio)",
    suffix:
      "High-contrast macro engineering studio photography on matte dark slate surface, diffused side softbox lighting, crisp alloy grain and machined bevels, 8k photorealistic quality.",
  },
];

const INITIAL_GALLERY: GeneratedRecord[] = [
  {
    id: "ref-hero",
    title: "التشريح الكامل لسيارة ميتسوبيشي L200 موديل 2016",
    prompt: "Isometric exploded cutaway of 2016 Mitsubishi L200 double-cab pickup truck",
    imageSize: "2K",
    aspectRatio: "16:9",
    src: GENERATED_GALLERY_IMAGES.heroCutaway,
    model: "لوحة مرجعية هندسية",
    isStaticReference: true,
  },
  {
    id: "ref-4n15",
    title: "مقطع تشريحي لمحرك الديزل 4N15 2.4L MIVEC",
    prompt: "Cross-section of 2.4L MIVEC aluminum diesel engine with VGT turbocharger",
    imageSize: "2K",
    aspectRatio: "4:3",
    src: GENERATED_GALLERY_IMAGES.engine4n15,
    model: "لوحة مرجعية هندسية",
    isStaticReference: true,
  },
  {
    id: "ref-4wd",
    title: "تفكيك ناقل الحركة وعلبة Super Select 4WD-II",
    prompt: "Exploded CAD of manual transmission, Super Select transfer case, and rear differential",
    imageSize: "2K",
    aspectRatio: "4:3",
    src: GENERATED_GALLERY_IMAGES.drivetrain4wd,
    model: "لوحة مرجعية هندسية",
    isStaticReference: true,
  },
  {
    id: "ref-chassis",
    title: "الشاصي السُّلمي RISE والتعليق المزدوج والسست",
    prompt: "CAD rendering of steel ladder-frame chassis with double wishbones and leaf springs",
    imageSize: "2K",
    aspectRatio: "4:3",
    src: GENERATED_GALLERY_IMAGES.chassisSuspension,
    model: "لوحة مرجعية هندسية",
    isStaticReference: true,
  },
];

export const ImageStudio: React.FC<ImageStudioProps> = ({ initialPart }) => {
  const [selectedPartId, setSelectedPartId] = useState<string>(
    initialPart?.id ?? SCIENTIFIC_PARTS[0].id
  );
  const [imageSize, setImageSize] = useState<ImageResolution>("2K");
  const [aspectRatio, setAspectRatio] = useState<ImageAspect>("16:9");
  const [styleId, setStyleId] = useState<string>("cutaway");
  const [prompt, setPrompt] = useState<string>(
    initialPart?.imagePrompt ?? SCIENTIFIC_PARTS[0].imagePrompt
  );
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [gallery, setGallery] = useState<GeneratedRecord[]>(INITIAL_GALLERY);

  useEffect(() => {
    if (initialPart) {
      setSelectedPartId(initialPart.id);
      setPrompt(initialPart.imagePrompt);
    }
  }, [initialPart]);

  const handlePartChange = (partId: string) => {
    setSelectedPartId(partId);
    const found = SCIENTIFIC_PARTS.find((p) => p.id === partId);
    if (found) {
      setPrompt(found.imagePrompt);
    }
  };

  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!prompt.trim()) return;

    setLoading(true);
    setErrorMsg(null);

    const styleObj = STYLE_MODIFIERS.find((s) => s.id === styleId);
    const finalPrompt = `${prompt.trim()} ${styleObj ? styleObj.suffix : ""}`.trim();
    const partObj = SCIENTIFIC_PARTS.find((p) => p.id === selectedPartId);

    try {
      const res = await fetch("/api/generate-image", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          prompt: finalPrompt,
          imageSize,
          aspectRatio,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        setErrorMsg(data.error ?? "تعذر توليد الصورة الهندسية.");
      } else {
        const record: GeneratedRecord = {
          id: `gen-${Date.now()}`,
          title: partObj ? `${partObj.nameAr} (${imageSize})` : `تصميم هندسي (${imageSize})`,
          prompt: finalPrompt,
          imageSize,
          aspectRatio,
          src: data.imageDataUrl,
          model: data.model ?? "gemini-3-pro-image-preview",
        };
        setGallery((prev) => [record, ...prev]);
      }
    } catch {
      setErrorMsg("تعذر الاتصال بالخادم لتوليد الصورة.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-[1280px] mx-auto px-4 sm:px-6 py-8 space-y-8">
      {/* Studio Control Surface */}
      <section className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        <form
          onSubmit={handleGenerate}
          className="lg:col-span-5 bg-[#111722] border border-white/10 rounded-xl p-6 space-y-5"
        >
          <div>
            <div className="text-xs text-slate-400 mb-1">
              النموذج: <span className="font-mono-tech text-amber-400">gemini-3-pro-image-preview</span>
            </div>
            <h2 className="text-lg font-bold text-white">
              استوديو توليد المخططات والصور الهندسية عالية الدقة
            </h2>
            <p className="text-xs text-slate-400 mt-1 leading-relaxed">
              اختر القطعة الميكانيكية من سيارة ميتسوبيشي L200 (2016)، وحدد الدقة المطلوبة
              (1K أو 2K أو 4K) لتوليد مخطط تشريحي أو صورة تفكيكية.
            </p>
          </div>

          {/* Part Selector */}
          <div className="space-y-1.5">
            <label
              htmlFor="part-select"
              className="block text-xs font-medium text-slate-300"
            >
              اختر القطعة الميكانيكية
            </label>
            <select
              id="part-select"
              value={selectedPartId}
              onChange={(e) => handlePartChange(e.target.value)}
              className="w-full bg-[#0B0F14] border border-white/12 rounded-lg px-3 py-2.5 text-xs text-white focus:outline-none focus:border-red-500"
            >
              {SCIENTIFIC_PARTS.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.partCode} — {p.nameAr}
                </option>
              ))}
            </select>
          </div>

          {/* Image Size Selector: 1K, 2K, 4K */}
          <div className="space-y-2">
            <span className="block text-xs font-medium text-slate-300">
              دقة الصورة المطلوبة (Image Size)
            </span>
            <div className="grid grid-cols-3 gap-2">
              {(
                [
                  { id: "1K", sub: "1024px قياسي" },
                  { id: "2K", sub: "2048px فائق" },
                  { id: "4K", sub: "4096px طباعي" },
                ] as const
              ).map((opt) => {
                const active = imageSize === opt.id;
                return (
                  <button
                    key={opt.id}
                    type="button"
                    onClick={() => setImageSize(opt.id)}
                    className={`p-2.5 rounded-lg border text-center transition-colors ${
                      active
                        ? "bg-red-600/20 border-red-500 text-white"
                        : "bg-[#0B0F14] border-white/10 text-slate-300 hover:border-white/25"
                    }`}
                  >
                    <div className="font-mono-tech text-sm font-bold">{opt.id}</div>
                    <div className="text-[11px] text-slate-400 mt-0.5">{opt.sub}</div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Aspect Ratio & Visual Style */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <span className="block text-xs font-medium text-slate-300">
                نسبة الأبعاد
              </span>
              <div className="grid grid-cols-3 gap-1.5">
                {(["16:9", "4:3", "1:1"] as const).map((ratio) => (
                  <button
                    key={ratio}
                    type="button"
                    onClick={() => setAspectRatio(ratio)}
                    className={`py-2 rounded-lg border font-mono-tech text-xs transition-colors ${
                      aspectRatio === ratio
                        ? "bg-slate-800 border-sky-400 text-white"
                        : "bg-[#0B0F14] border-white/10 text-slate-400 hover:text-white"
                    }`}
                  >
                    {ratio}
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-1.5">
              <label
                htmlFor="style-select"
                className="block text-xs font-medium text-slate-300"
              >
                النمط الهندسي
              </label>
              <select
                id="style-select"
                value={styleId}
                onChange={(e) => setStyleId(e.target.value)}
                className="w-full bg-[#0B0F14] border border-white/12 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-red-500"
              >
                {STYLE_MODIFIERS.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.label}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Prompt Editor */}
          <div className="space-y-1.5">
            <label
              htmlFor="image-prompt"
              className="block text-xs font-medium text-slate-300"
            >
              الوصف الهندسي للصورة (قابل للتعديل)
            </label>
            <textarea
              id="image-prompt"
              rows={4}
              dir="auto"
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              className="w-full bg-[#0B0F14] border border-white/12 rounded-lg p-3 text-xs text-slate-100 leading-relaxed focus:outline-none focus:border-red-500"
            />
          </div>

          {errorMsg && (
            <div className="p-3.5 rounded-lg bg-red-950/50 border border-red-500/40 text-xs text-red-200 leading-relaxed">
              {errorMsg}
            </div>
          )}

          <button
            type="submit"
            disabled={loading || !prompt.trim()}
            className="w-full inline-flex items-center justify-center gap-2 px-4 py-3 rounded-lg bg-red-600 hover:bg-red-500 disabled:opacity-50 text-white text-sm font-semibold transition-colors"
          >
            {loading ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>جارٍ التوليد بدقة {imageSize}...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4" />
                <span>توليد صورة هندسية بدقة {imageSize}</span>
              </>
            )}
          </button>
        </form>

        {/* Gallery Output */}
        <div className="lg:col-span-7 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <ImageIcon className="w-4 h-4 text-sky-400" />
              <span>معرض اللوحات الهندسية والمخططات المولّدة</span>
            </h3>
            <span className="text-xs text-slate-400 font-mono-tech">
              {gallery.length} لوحات
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {gallery.map((item) => (
              <article
                key={item.id}
                className="bg-[#111722] border border-white/10 rounded-xl overflow-hidden flex flex-col"
              >
                <div className="relative aspect-video bg-[#0B0F14] overflow-hidden">
                  <img
                    src={item.src}
                    alt={item.title}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover"
                  />
                  <img
                    src="/assets/brand/logo_white.png"
                    alt=""
                    referrerPolicy="no-referrer"
                    className="pointer-events-none absolute bottom-2.5 left-2.5 w-14 h-14 object-contain opacity-85 drop-shadow-[0_2px_8px_rgba(0,0,0,0.8)]"
                  />
                </div>
                <div className="p-4 flex-1 flex flex-col justify-between gap-3">
                  <div>
                    <div className="text-[11px] text-slate-400 font-mono-tech mb-1">
                      <span>{item.imageSize}</span>
                      <span aria-hidden="true" className="mx-1.5">
                        ·
                      </span>
                      <span>{item.aspectRatio}</span>
                      <span aria-hidden="true" className="mx-1.5">
                        ·
                      </span>
                      <span>{item.model}</span>
                    </div>
                    <h4 className="text-sm font-bold text-white leading-snug">
                      {item.title}
                    </h4>
                  </div>

                  <a
                    href={item.src}
                    download={`l200-2016-${item.id}.png`}
                    className="inline-flex items-center justify-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-medium text-slate-100 transition-colors"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>تنزيل اللوحة ({item.imageSize})</span>
                  </a>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};
