import React, { useMemo, useState } from "react";
import { L200_ASSEMBLIES, VEHICLE_OVERVIEW_SPECS } from "../data/l200Data";

const GEAR_RATIOS = [
  { gear: "الترس 1", ratio: 4.313 },
  { gear: "الترس 2", ratio: 2.33 },
  { gear: "الترس 3", ratio: 1.436 },
  { gear: "الترس 4", ratio: 1.0 },
  { gear: "الترس 5", ratio: 0.788 },
  { gear: "الترس 6", ratio: 0.671 },
];

// Approximate 4N15 2.4L MIVEC torque curve (N·m) by RPM
function get4N15Torque(rpm: number): number {
  if (rpm <= 1000) return 210;
  if (rpm <= 1500) return 210 + ((rpm - 1000) / 500) * 140; // 350 Nm @ 1500
  if (rpm <= 2500) return 350 + ((rpm - 1500) / 1000) * 80; // 430 Nm @ 2500
  if (rpm <= 3500) return 430 - ((rpm - 2500) / 1000) * 67; // 363 Nm @ 3500 (133 kW)
  return Math.max(290, 363 - ((rpm - 3500) / 500) * 45);
}

export const PhysicsSpecsView: React.FC = () => {
  const [rpm, setRpm] = useState(2500);
  const [gearIdx, setGearIdx] = useState(0);
  const [lowRange, setLowRange] = useState(false);
  const [speedKmh, setSpeedKmh] = useState(100);
  const [tireBar, setTireBar] = useState(2.2);

  const drivetrainMetrics = useMemo(() => {
    const engineTorque = get4N15Torque(rpm);
    const enginePowerKw = (engineTorque * rpm) / 9549;
    const gearRatio = GEAR_RATIOS[gearIdx].ratio;
    const transferRatio = lowRange ? 2.566 : 1.0;
    const finalDrive = 3.917;
    const efficiency = 0.88;

    const totalRatio = gearRatio * transferRatio * finalDrive;
    const wheelTorque = engineTorque * totalRatio * efficiency;
    const wheelRadiusM = 0.375; // 245/65R17
    const tractiveForceN = wheelTorque / wheelRadiusM;

    const wheelRpm = rpm / totalRatio;
    const calcSpeedKmh = wheelRpm * (2 * Math.PI * wheelRadiusM) * 0.06;

    return {
      engineTorque: Math.round(engineTorque),
      enginePowerKw: enginePowerKw.toFixed(1),
      enginePowerPs: Math.round(enginePowerKw * 1.3596),
      totalRatio: totalRatio.toFixed(2),
      wheelTorque: Math.round(wheelTorque),
      tractiveForceKn: (tractiveForceN / 1000).toFixed(2),
      calcSpeedKmh: calcSpeedKmh.toFixed(1),
    };
  }, [rpm, gearIdx, lowRange]);

  const aeroBrakeMetrics = useMemo(() => {
    const v = speedKmh / 3.6; // m/s
    const rho = 1.225; // kg/m^3
    const cd = 0.4;
    const frontalArea = 2.95; // m^2 for L200 2016
    const dragForceN = 0.5 * rho * cd * frontalArea * v * v;
    const dragPowerKw = (dragForceN * v) / 1000;

    const massKg = 1910;
    const kineticEnergyKj = (0.5 * massKg * v * v) / 1000;

    // Approximate contact patch area per tire (Load ~ 477 kg * 9.81 = 4680 N / pressure Pa)
    const tirePressureKpa = tireBar * 100;
    const patchPerTireCm2 = (4680 / (tirePressureKpa * 1000)) * 10000;

    return {
      dragForceN: Math.round(dragForceN),
      dragPowerKw: dragPowerKw.toFixed(1),
      kineticEnergyKj: Math.round(kineticEnergyKj),
      patchPerTireCm2: Math.round(patchPerTireCm2),
    };
  }, [speedKmh, tireBar]);

  const totalMass = L200_ASSEMBLIES.reduce((acc, a) => acc + a.massEstimateKg, 0);

  return (
    <div className="max-w-[1280px] mx-auto px-4 sm:px-6 py-8 space-y-8">
      <div className="space-y-2">
        <h1 className="text-2xl font-bold text-white">
          المختبر الفيزيائي ومعادلات الأداء — Mitsubishi L200 (2016)
        </h1>
        <p className="text-sm text-slate-400 max-w-3xl">
          محاكاة حسابية مباشرة للعزم الواصل إلى العجلات، المقاومة الهوائية، وطاقة
          الكبح الحرارية بناءً على المواصفات القياسية لمحرك 4N15 وعلبة Super Select 4WD-II.
        </p>
      </div>

      {/* Interactive Simulators Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Simulator 1: Torque & 4WD Reduction */}
        <section className="bg-[#111722] border border-white/10 rounded-xl p-6 space-y-5">
          <div>
            <h2 className="text-base font-bold text-white">
              01. حاسبة تضاعف العزم ونظام الدفع الرباعي (Super Select 4WD-II)
            </h2>
            <p className="text-xs text-slate-400 mt-1">
              اضبط سرعة المحرك والترس ووضع الدبل الثقيل لحساب قوة الجر الفيزيائية.
            </p>
          </div>

          <div className="space-y-4">
            <div>
              <div className="flex justify-between text-xs mb-1.5">
                <span className="text-slate-300">سرعة دوران المحرك (RPM)</span>
                <span className="font-mono-tech text-red-400 font-semibold">
                  {rpm} rpm
                </span>
              </div>
              <input
                type="range"
                min={1000}
                max={4000}
                step={100}
                value={rpm}
                onChange={(e) => setRpm(Number(e.target.value))}
                className="cad-slider w-full"
              />
            </div>

            <div className="flex flex-wrap gap-1.5">
              {GEAR_RATIOS.map((g, idx) => (
                <button
                  key={g.gear}
                  type="button"
                  onClick={() => setGearIdx(idx)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-medium border transition-colors ${
                    gearIdx === idx
                      ? "bg-red-600 text-white border-red-500"
                      : "bg-[#0B0F14] text-slate-300 border-white/10 hover:text-white"
                  }`}
                >
                  {g.gear} ({g.ratio})
                </button>
              ))}
            </div>

            <div className="flex items-center justify-between bg-[#0B0F14] border border-white/10 rounded-lg p-3">
              <span className="text-xs text-slate-200">
                وضع الدبل الثقيل (4LLc · تخفيض 2.566:1)
              </span>
              <button
                type="button"
                onClick={() => setLowRange((l) => !l)}
                className={`px-3 py-1 rounded-md text-xs font-semibold transition-colors ${
                  lowRange
                    ? "bg-amber-500 text-slate-950"
                    : "bg-slate-800 text-slate-300 hover:text-white"
                }`}
              >
                {lowRange ? "مفعّل (4LLc)" : "عادي (2H / 4H)"}
              </button>
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 pt-2">
            <div className="bg-[#0B0F14] border border-white/8 rounded-lg p-3">
              <div className="text-[11px] text-slate-400">عزم المحرك</div>
              <div className="font-mono-tech text-lg font-bold text-white mt-0.5">
                {drivetrainMetrics.engineTorque} N·m
              </div>
            </div>
            <div className="bg-[#0B0F14] border border-white/8 rounded-lg p-3">
              <div className="text-[11px] text-slate-400">القدرة اللحظية</div>
              <div className="font-mono-tech text-lg font-bold text-sky-400 mt-0.5">
                {drivetrainMetrics.enginePowerPs} PS
              </div>
            </div>
            <div className="bg-[#0B0F14] border border-white/8 rounded-lg p-3">
              <div className="text-[11px] text-slate-400">النسبة الكلية</div>
              <div className="font-mono-tech text-lg font-bold text-amber-400 mt-0.5">
                {drivetrainMetrics.totalRatio}:1
              </div>
            </div>
            <div className="bg-[#0B0F14] border border-white/8 rounded-lg p-3">
              <div className="text-[11px] text-slate-400">العزم عند العجلات</div>
              <div className="font-mono-tech text-lg font-bold text-red-400 mt-0.5">
                {drivetrainMetrics.wheelTorque} N·m
              </div>
            </div>
            <div className="bg-[#0B0F14] border border-white/8 rounded-lg p-3">
              <div className="text-[11px] text-slate-400">قوة الجر الخطية</div>
              <div className="font-mono-tech text-lg font-bold text-emerald-400 mt-0.5">
                {drivetrainMetrics.tractiveForceKn} kN
              </div>
            </div>
            <div className="bg-[#0B0F14] border border-white/8 rounded-lg p-3">
              <div className="text-[11px] text-slate-400">السرعة المحسوبة</div>
              <div className="font-mono-tech text-lg font-bold text-white mt-0.5">
                {drivetrainMetrics.calcSpeedKmh} km/h
              </div>
            </div>
          </div>
        </section>

        {/* Simulator 2: Aerodynamics, Braking Energy & Tire Patch */}
        <section className="bg-[#111722] border border-white/10 rounded-xl p-6 space-y-5">
          <div>
            <h2 className="text-base font-bold text-white">
              02. الديناميكا الهوائية وطاقة الكبح الحرارية ورقعة التماس
            </h2>
            <p className="text-xs text-slate-400 mt-1">
              حساب المقاومة الهوائية (Cd=0.40) والطاقة الممتصة في المكابح ومساحة تماس الإطار.
            </p>
          </div>

          <div className="space-y-4">
            <div>
              <div className="flex justify-between text-xs mb-1.5">
                <span className="text-slate-300">سرعة المركبة</span>
                <span className="font-mono-tech text-sky-400 font-semibold">
                  {speedKmh} km/h
                </span>
              </div>
              <input
                type="range"
                min={20}
                max={175}
                step={5}
                value={speedKmh}
                onChange={(e) => setSpeedKmh(Number(e.target.value))}
                className="cad-slider w-full"
              />
            </div>

            <div>
              <div className="flex justify-between text-xs mb-1.5">
                <span className="text-slate-300">ضغط الإطارات (245/65R17)</span>
                <span className="font-mono-tech text-amber-400 font-semibold">
                  {tireBar.toFixed(1)} bar ({Math.round(tireBar * 14.5)} PSI)
                </span>
              </div>
              <input
                type="range"
                min={1.0}
                max={2.8}
                step={0.1}
                value={tireBar}
                onChange={(e) => setTireBar(Number(e.target.value))}
                className="cad-slider w-full"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3 pt-2">
            <div className="bg-[#0B0F14] border border-white/8 rounded-lg p-3.5">
              <div className="text-[11px] text-slate-400">قوة السحب الهوائي (Fd)</div>
              <div className="font-mono-tech text-xl font-bold text-white mt-0.5">
                {aeroBrakeMetrics.dragForceN} N
              </div>
              <div className="text-[11px] text-slate-500 mt-1">
                تزداد مع مربع السرعة v²
              </div>
            </div>

            <div className="bg-[#0B0F14] border border-white/8 rounded-lg p-3.5">
              <div className="text-[11px] text-slate-400">القدرة المفقودة للهواء</div>
              <div className="font-mono-tech text-xl font-bold text-sky-400 mt-0.5">
                {aeroBrakeMetrics.dragPowerKw} kW
              </div>
              <div className="text-[11px] text-slate-500 mt-1">
                تتناسب مع مكعب السرعة v³
              </div>
            </div>

            <div className="bg-[#0B0F14] border border-white/8 rounded-lg p-3.5">
              <div className="text-[11px] text-slate-400">طاقة الكبح للتوقف (Ek)</div>
              <div className="font-mono-tech text-xl font-bold text-red-400 mt-0.5">
                {aeroBrakeMetrics.kineticEnergyKj} kJ
              </div>
              <div className="text-[11px] text-slate-500 mt-1">
                تتحول لحرارة في أقراص 294 ملم
              </div>
            </div>

            <div className="bg-[#0B0F14] border border-white/8 rounded-lg p-3.5">
              <div className="text-[11px] text-slate-400">مساحة تماس الإطار الواحد</div>
              <div className="font-mono-tech text-xl font-bold text-emerald-400 mt-0.5">
                {aeroBrakeMetrics.patchPerTireCm2} cm²
              </div>
              <div className="text-[11px] text-slate-500 mt-1">
                تتضاعف عند خفض الضغط للرمال
              </div>
            </div>
          </div>
        </section>
      </div>

      {/* Assembly Mass Distribution Table */}
      <section className="bg-[#111722] border border-white/10 rounded-xl overflow-hidden">
        <div className="p-5 border-b border-white/8 flex flex-wrap items-center justify-between gap-2">
          <h2 className="text-base font-bold text-white">
            توزيع الكتلة التفكيكي للمنظومات الثماني (الإجمالي الفارغ: {totalMass} kg)
          </h2>
          <span className="text-xs text-slate-400 font-mono-tech">
            {VEHICLE_OVERVIEW_SPECS[0].value}
          </span>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-right text-xs">
            <thead className="bg-[#0B0F14] text-slate-400 border-b border-white/8">
              <tr>
                <th className="py-3 px-4 font-medium">الرمز</th>
                <th className="py-3 px-4 font-medium">المنظومة الهندسية</th>
                <th className="py-3 px-4 font-medium">الكتلة التقديرية</th>
                <th className="py-3 px-4 font-medium">النسبة من الوزن</th>
                <th className="py-3 px-4 font-medium">الملخص الميكانيكي</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/6">
              {L200_ASSEMBLIES.map((asm) => {
                const pct = ((asm.massEstimateKg / totalMass) * 100).toFixed(1);
                return (
                  <tr key={asm.id} className="hover:bg-white/[0.02]">
                    <td className="py-3 px-4 font-mono-tech text-amber-400">
                      {asm.indexLabel}
                    </td>
                    <td className="py-3 px-4 font-semibold text-white">
                      {asm.nameAr}
                    </td>
                    <td className="py-3 px-4 font-mono-tech text-slate-200">
                      {asm.massEstimateKg} kg
                    </td>
                    <td className="py-3 px-4 font-mono-tech text-sky-400">
                      {pct}%
                    </td>
                    <td className="py-3 px-4 text-slate-400 max-w-md">
                      {asm.summaryAr}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
};
