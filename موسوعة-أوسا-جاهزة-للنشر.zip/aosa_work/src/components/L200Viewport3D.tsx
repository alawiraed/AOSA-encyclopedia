import React, { useEffect, useRef, useState } from "react";
import * as THREE from "three";
import { OrbitControls } from "three/addons/controls/OrbitControls.js";
import { RoomEnvironment } from "three/addons/environments/RoomEnvironment.js";
import {
  ChevronDown,
  ChevronUp,
  Eye,
  EyeOff,
  Layers,
  Maximize2,
  RotateCcw,
} from "lucide-react";
import { AssemblyId, L200_ASSEMBLIES } from "../data/l200Data";

interface L200Viewport3DProps {
  explodeFactor: number;
  onExplodeChange: (val: number) => void;
  selectedAssemblyId: AssemblyId;
  onSelectAssembly: (id: AssemblyId) => void;
  isolatedAssembly: AssemblyId | null;
  onToggleIsolate: (id: AssemblyId | null) => void;
  cameraFocusTick: number;
}

interface AssemblyMeta {
  group: THREE.Group;
  basePos: THREE.Vector3;
  explodeOffset: THREE.Vector3;
  materials: THREE.MeshStandardMaterial[];
}

// Pre-allocated math helpers outside render loop (zero GC)
const _tmpVec = new THREE.Vector3();
const _tmpTarget = new THREE.Vector3();

function createStudioGridTexture(maxAnisotropy: number): THREE.CanvasTexture {
  const canvas = document.createElement("canvas");
  canvas.width = 512;
  canvas.height = 512;
  const ctx = canvas.getContext("2d")!;

  ctx.fillStyle = "#0b0f14";
  ctx.fillRect(0, 0, 512, 512);

  // Sub-grid
  ctx.strokeStyle = "rgba(148, 163, 184, 0.06)";
  ctx.lineWidth = 1;
  for (let i = 0; i <= 512; i += 32) {
    ctx.beginPath();
    ctx.moveTo(i, 0);
    ctx.lineTo(i, 512);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(0, i);
    ctx.lineTo(512, i);
    ctx.stroke();
  }

  // Major CAD grid line
  ctx.strokeStyle = "rgba(148, 163, 184, 0.14)";
  ctx.lineWidth = 1.5;
  ctx.strokeRect(0, 0, 512, 512);

  const tex = new THREE.CanvasTexture(canvas);
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(16, 16);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = maxAnisotropy;
  return tex;
}

function createContactShadowTexture(): THREE.CanvasTexture {
  const canvas = document.createElement("canvas");
  canvas.width = 256;
  canvas.height = 256;
  const ctx = canvas.getContext("2d")!;
  const grad = ctx.createRadialGradient(128, 128, 12, 128, 128, 124);
  grad.addColorStop(0, "rgba(0, 0, 0, 0.78)");
  grad.addColorStop(0.55, "rgba(0, 0, 0, 0.36)");
  grad.addColorStop(1, "rgba(0, 0, 0, 0)");
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, 256, 256);
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

function createHelixCurve(
  radius: number,
  height: number,
  turns: number,
  segments = 64
): THREE.CatmullRomCurve3 {
  const pts: THREE.Vector3[] = [];
  for (let i = 0; i <= segments; i++) {
    const t = i / segments;
    const angle = t * Math.PI * 2 * turns;
    pts.push(
      new THREE.Vector3(
        Math.cos(angle) * radius,
        (t - 0.5) * height,
        Math.sin(angle) * radius
      )
    );
  }
  return new THREE.CatmullRomCurve3(pts);
}

export const L200Viewport3D: React.FC<L200Viewport3DProps> = ({
  explodeFactor,
  onExplodeChange,
  selectedAssemblyId,
  onSelectAssembly,
  isolatedAssembly,
  onToggleIsolate,
  cameraFocusTick,
}) => {
  const mountRef = useRef<HTMLDivElement | null>(null);
  const [xrayBody, setXrayBody] = useState(true);
  const [dockCollapsed, setDockCollapsed] = useState(false);
  const [hoveredName, setHoveredName] = useState<string | null>(null);
  const [contextLost, setContextLost] = useState(false);

  // Refs to keep Three.js loop stable across React re-renders
  const explodeTargetRef = useRef(explodeFactor);
  const selectedIdRef = useRef(selectedAssemblyId);
  const isolatedRef = useRef(isolatedAssembly);
  const xrayRef = useRef(xrayBody);
  const onSelectRef = useRef(onSelectAssembly);
  const requestRenderRef = useRef<(() => void) | null>(null);
  const cameraGoalRef = useRef<{
    active: boolean;
    pos: THREE.Vector3;
    target: THREE.Vector3;
  }>({
    active: false,
    pos: new THREE.Vector3(4.6, 2.25, 4.35),
    target: new THREE.Vector3(0, 0.72, 0),
  });

  useEffect(() => {
    explodeTargetRef.current = explodeFactor;
    requestRenderRef.current?.();
  }, [explodeFactor]);

  useEffect(() => {
    selectedIdRef.current = selectedAssemblyId;
    requestRenderRef.current?.();
  }, [selectedAssemblyId]);

  useEffect(() => {
    isolatedRef.current = isolatedAssembly;
    requestRenderRef.current?.();
  }, [isolatedAssembly]);

  useEffect(() => {
    xrayRef.current = xrayBody;
    requestRenderRef.current?.();
  }, [xrayBody]);

  useEffect(() => {
    onSelectRef.current = onSelectAssembly;
  }, [onSelectAssembly]);

  useEffect(() => {
    if (cameraFocusTick === 0) return;
    const found = L200_ASSEMBLIES.find((a) => a.id === selectedAssemblyId);
    if (found) {
      cameraGoalRef.current.pos.set(...found.cameraPreset.position);
      cameraGoalRef.current.target.set(...found.cameraPreset.target);
      cameraGoalRef.current.active = true;
      requestRenderRef.current?.();
    }
  }, [cameraFocusTick, selectedAssemblyId]);

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    // 1. Software WebGL detection
    const isSoftwareGl = (() => {
      const probe = document.createElement("canvas").getContext("webgl2");
      if (!probe) return true;
      const ext = probe.getExtension("WEBGL_debug_renderer_info");
      const param = ext ? ext.UNMASKED_RENDERER_WEBGL : probe.RENDERER;
      const gpu = String(probe.getParameter(param));
      probe.getExtension("WEBGL_lose_context")?.loseContext();
      return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
    })();

    const width = Math.max(container.clientWidth, 320);
    const height = Math.max(container.clientHeight, 320);

    // 2. Scene, Camera, Renderer
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x0b0f14);
    scene.fog = new THREE.FogExp2(0x0b0f14, 0.042);

    const camera = new THREE.PerspectiveCamera(40, width / height, 0.1, 100);
    camera.position.set(4.6, 2.25, 4.35);

    const renderer = new THREE.WebGLRenderer({
      antialias: !isSoftwareGl,
      powerPreference: "high-performance",
    });
    renderer.setSize(width, height);
    renderer.setPixelRatio(isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.12;
    renderer.shadowMap.enabled = !isSoftwareGl;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    container.appendChild(renderer.domElement);

    // 3. Studio Environment Reflection (RoomEnvironment)
    const pmremGenerator = new THREE.PMREMGenerator(renderer);
    const envTexture = pmremGenerator.fromScene(new RoomEnvironment(), 0.04).texture;
    scene.environment = envTexture;
    pmremGenerator.dispose();

    // 4. Three-Point Studio Lighting
    const hemiLight = new THREE.HemisphereLight(0xcbd5e1, 0x1e293b, 0.65);
    scene.add(hemiLight);

    const keyLight = new THREE.DirectionalLight(0xfff4e6, 2.2);
    keyLight.position.set(6, 9, 6);
    keyLight.castShadow = !isSoftwareGl;
    keyLight.shadow.mapSize.set(1024, 1024);
    keyLight.shadow.camera.near = 1;
    keyLight.shadow.camera.far = 25;
    keyLight.shadow.camera.left = -5;
    keyLight.shadow.camera.right = 5;
    keyLight.shadow.camera.top = 5;
    keyLight.shadow.camera.bottom = -5;
    keyLight.shadow.bias = -0.0005;
    keyLight.shadow.normalBias = 0.02;
    scene.add(keyLight);

    const rimLight = new THREE.DirectionalLight(0x7dd3fc, 1.15);
    rimLight.position.set(-6, 5, -5);
    scene.add(rimLight);

    // 5. Ground CAD Grid & Contact Shadow
    const maxAniso = renderer.capabilities.getMaxAnisotropy();
    const gridTex = createStudioGridTexture(maxAniso);
    const floorMat = new THREE.MeshStandardMaterial({
      map: gridTex,
      roughness: 0.88,
      metalness: 0.15,
    });
    const floor = new THREE.Mesh(new THREE.PlaneGeometry(36, 36), floorMat);
    floor.rotation.x = -Math.PI / 2;
    floor.position.y = 0;
    floor.receiveShadow = true;
    scene.add(floor);

    const contactTex = createContactShadowTexture();
    const contactShadow = new THREE.Mesh(
      new THREE.PlaneGeometry(5.6, 2.9),
      new THREE.MeshBasicMaterial({
        map: contactTex,
        transparent: true,
        depthWrite: false,
        opacity: 0.65,
      })
    );
    contactShadow.rotation.x = -Math.PI / 2;
    contactShadow.rotation.z = Math.PI / 2;
    contactShadow.position.y = 0.015;
    scene.add(contactShadow);

    // 6. Controls
    const controls = new OrbitControls(camera, renderer.domElement);
    controls.target.set(0, 0.72, 0);
    controls.enableDamping = !isSoftwareGl;
    controls.dampingFactor = 0.06;
    controls.minDistance = 2.0;
    controls.maxDistance = 12.0;
    controls.maxPolarAngle = Math.PI / 2 - 0.04;
    controls.update();

    // Cancel automatic camera transition when user interacts manually
    const onControlStart = () => {
      cameraGoalRef.current.active = false;
    };
    controls.addEventListener("start", onControlStart);

    // 7. Build Composite Procedural 2016 Mitsubishi L200 Assemblies
    const vehicleRoot = new THREE.Group();
    scene.add(vehicleRoot);

    const assemblies = new Map<AssemblyId, AssemblyMeta>();
    const clickableMeshes: THREE.Object3D[] = [];
    const disposableGeometries: THREE.BufferGeometry[] = [];
    const disposableMaterials: THREE.Material[] = [];

    const makeMat = (
      params: THREE.MeshStandardMaterialParameters,
      assemblyId: AssemblyId
    ) => {
      const m = new THREE.MeshStandardMaterial(params);
      m.userData.baseColor = m.color.getHex();
      m.userData.baseOpacity = params.opacity ?? 1;
      m.userData.assemblyId = assemblyId;
      disposableMaterials.push(m);
      return m;
    };

    const registerGeo = <T extends THREE.BufferGeometry>(g: T): T => {
      disposableGeometries.push(g);
      return g;
    };

    const tagGroup = (group: THREE.Group, id: AssemblyId, label: string) => {
      group.traverse((child) => {
        if ((child as THREE.Mesh).isMesh) {
          const mesh = child as THREE.Mesh;
          mesh.castShadow = !isSoftwareGl;
          mesh.receiveShadow = true;
          mesh.userData.assemblyId = id;
          mesh.userData.labelAr = label;
          mesh.layers.enable(1);
          clickableMeshes.push(mesh);
        }
      });
    };

    // --- ASSEMBLY 03: LADDER-FRAME CHASSIS (RISE) ---
    {
      const id: AssemblyId = "chassis";
      const grp = new THREE.Group();
      const matSteel = makeMat(
        { color: 0x334155, metalness: 0.78, roughness: 0.42 },
        id
      );
      const matWeld = makeMat(
        { color: 0x475569, metalness: 0.85, roughness: 0.35 },
        id
      );

      // Left & Right Boxed Ladder Rails
      const railGeo = registerGeo(new THREE.BoxGeometry(0.11, 0.14, 4.55));
      for (const side of [-0.42, 0.42]) {
        const rail = new THREE.Mesh(railGeo, matSteel);
        rail.position.set(side, 0.48, 0);
        grp.add(rail);

        // Rear axle kick-up arch
        const kickGeo = registerGeo(new THREE.BoxGeometry(0.11, 0.14, 0.95));
        const kick = new THREE.Mesh(kickGeo, matSteel);
        kick.position.set(side, 0.57, -1.35);
        grp.add(kick);
      }

      // 6 Crossmembers
      const crossGeo = registerGeo(new THREE.BoxGeometry(0.92, 0.1, 0.1));
      const crossZ = [2.18, 1.45, 0.55, -0.35, -1.25, -2.18];
      for (const z of crossZ) {
        const xm = new THREE.Mesh(crossGeo, matWeld);
        xm.position.set(0, z < -1.0 ? 0.55 : 0.47, z);
        grp.add(xm);
      }

      // Front Crash Horns
      const hornGeo = registerGeo(new THREE.BoxGeometry(0.12, 0.12, 0.25));
      for (const side of [-0.42, 0.42]) {
        const horn = new THREE.Mesh(hornGeo, matWeld);
        horn.position.set(side, 0.48, 2.32);
        grp.add(horn);
      }

      tagGroup(grp, id, "الشاصي السُّلمي (RISE Ladder Frame)");
      vehicleRoot.add(grp);
      assemblies.set(id, {
        group: grp,
        basePos: new THREE.Vector3(0, 0, 0),
        explodeOffset: new THREE.Vector3(0, -0.25, 0),
        materials: [matSteel, matWeld],
      });
    }

    // --- ASSEMBLY 01: 4N15 2.4L MIVEC TURBO-DIESEL ENGINE ---
    {
      const id: AssemblyId = "engine";
      const grp = new THREE.Group();
      const matAlum = makeMat(
        { color: 0xcbd5e1, metalness: 0.88, roughness: 0.26 },
        id
      );
      const matHead = makeMat(
        { color: 0x1e293b, metalness: 0.45, roughness: 0.55 },
        id
      );
      const matCrimson = makeMat(
        { color: 0xdc2626, metalness: 0.65, roughness: 0.3 },
        id
      );
      const matTurbo = makeMat(
        { color: 0x94a3b8, metalness: 0.92, roughness: 0.22 },
        id
      );

      // Aluminum cylinder block
      const block = new THREE.Mesh(
        registerGeo(new THREE.BoxGeometry(0.46, 0.36, 0.68)),
        matAlum
      );
      block.position.set(0, 0.72, 1.38);
      grp.add(block);

      // Oil sump pan
      const sump = new THREE.Mesh(
        registerGeo(new THREE.BoxGeometry(0.42, 0.14, 0.62)),
        matHead
      );
      sump.position.set(0, 0.48, 1.38);
      grp.add(sump);

      // DOHC MIVEC Cylinder Head + Acoustic Cover
      const head = new THREE.Mesh(
        registerGeo(new THREE.BoxGeometry(0.48, 0.16, 0.68)),
        matAlum
      );
      head.position.set(0, 0.97, 1.38);
      grp.add(head);

      const valveCover = new THREE.Mesh(
        registerGeo(new THREE.BoxGeometry(0.4, 0.08, 0.62)),
        matCrimson
      );
      valveCover.position.set(0, 1.09, 1.38);
      grp.add(valveCover);

      // 4 Common-Rail Injectors along top
      const injGeo = registerGeo(new THREE.CylinderGeometry(0.025, 0.025, 0.12, 12));
      for (let i = 0; i < 4; i++) {
        const inj = new THREE.Mesh(injGeo, matTurbo);
        inj.position.set(0.08, 1.14, 1.15 + i * 0.15);
        grp.add(inj);
      }

      // Variable Geometry Turbocharger (VGT) on side
      const turboHousing = new THREE.Mesh(
        registerGeo(new THREE.TorusGeometry(0.09, 0.045, 12, 24)),
        matTurbo
      );
      turboHousing.rotation.y = Math.PI / 2;
      turboHousing.position.set(-0.33, 0.82, 1.34);
      grp.add(turboHousing);

      const turboCore = new THREE.Mesh(
        registerGeo(new THREE.CylinderGeometry(0.06, 0.06, 0.18, 16)),
        matAlum
      );
      turboCore.rotation.x = Math.PI / 2;
      turboCore.position.set(-0.33, 0.82, 1.44);
      grp.add(turboCore);

      // Front Pulleys & Alternator
      const pulleyGeo = registerGeo(new THREE.CylinderGeometry(0.08, 0.08, 0.04, 20));
      const crankPulley = new THREE.Mesh(pulleyGeo, matHead);
      crankPulley.rotation.x = Math.PI / 2;
      crankPulley.position.set(0, 0.66, 1.75);
      grp.add(crankPulley);

      const alternator = new THREE.Mesh(
        registerGeo(new THREE.CylinderGeometry(0.075, 0.075, 0.15, 16)),
        matAlum
      );
      alternator.rotation.x = Math.PI / 2;
      alternator.position.set(0.24, 0.88, 1.66);
      grp.add(alternator);

      tagGroup(grp, id, "محرك 4N15 2.4L MIVEC التوربيني");
      vehicleRoot.add(grp);
      assemblies.set(id, {
        group: grp,
        basePos: new THREE.Vector3(0, 0, 0),
        explodeOffset: new THREE.Vector3(0, 0.95, 0.65),
        materials: [matAlum, matHead, matCrimson, matTurbo],
      });
    }

    // --- ASSEMBLY 06: COOLING & INTERCOOLER ---
    {
      const id: AssemblyId = "cooling";
      const grp = new THREE.Group();
      const matFin = makeMat(
        { color: 0x94a3b8, metalness: 0.82, roughness: 0.32 },
        id
      );
      const matTank = makeMat(
        { color: 0x0f172a, metalness: 0.2, roughness: 0.65 },
        id
      );
      const matHose = makeMat(
        { color: 0x0284c7, metalness: 0.1, roughness: 0.45 },
        id
      );

      // Main Dual-Row Radiator
      const rad = new THREE.Mesh(
        registerGeo(new THREE.BoxGeometry(0.86, 0.5, 0.08)),
        matFin
      );
      rad.position.set(0, 0.78, 1.98);
      grp.add(rad);

      // Intercooler FMIC
      const ic = new THREE.Mesh(
        registerGeo(new THREE.BoxGeometry(0.68, 0.24, 0.09)),
        matFin
      );
      ic.position.set(0, 0.56, 2.12);
      grp.add(ic);

      // Viscous Cooling Fan Hub
      const fanHub = new THREE.Mesh(
        registerGeo(new THREE.CylinderGeometry(0.18, 0.18, 0.05, 20)),
        matTank
      );
      fanHub.rotation.x = Math.PI / 2;
      fanHub.position.set(0, 0.78, 1.9);
      grp.add(fanHub);

      // Intercooler Boost Pipe
      const boostCurve = new THREE.CatmullRomCurve3([
        new THREE.Vector3(-0.34, 0.56, 2.12),
        new THREE.Vector3(-0.42, 0.65, 1.85),
        new THREE.Vector3(-0.33, 0.82, 1.54),
      ]);
      const boostPipe = new THREE.Mesh(
        registerGeo(new THREE.TubeGeometry(boostCurve, 20, 0.032, 10, false)),
        matHose
      );
      grp.add(boostPipe);

      tagGroup(grp, id, "منظومة التبريد والمبرد البيني (Intercooler)");
      vehicleRoot.add(grp);
      assemblies.set(id, {
        group: grp,
        basePos: new THREE.Vector3(0, 0, 0),
        explodeOffset: new THREE.Vector3(0, 0.35, 1.35),
        materials: [matFin, matTank, matHose],
      });
    }

    // --- ASSEMBLY 02: SUPER SELECT 4WD-II DRIVETRAIN ---
    {
      const id: AssemblyId = "drivetrain";
      const grp = new THREE.Group();
      const matCase = makeMat(
        { color: 0x94a3b8, metalness: 0.85, roughness: 0.3 },
        id
      );
      const matShaft = makeMat(
        { color: 0x475569, metalness: 0.88, roughness: 0.25 },
        id
      );
      const matAccent = makeMat(
        { color: 0xd97706, metalness: 0.75, roughness: 0.35 },
        id
      );

      // Bellhousing & Gearbox
      const bell = new THREE.Mesh(
        registerGeo(new THREE.CylinderGeometry(0.16, 0.22, 0.28, 18)),
        matCase
      );
      bell.rotation.x = Math.PI / 2;
      bell.position.set(0, 0.6, 0.88);
      grp.add(bell);

      const gearbox = new THREE.Mesh(
        registerGeo(new THREE.BoxGeometry(0.3, 0.28, 0.56)),
        matCase
      );
      gearbox.position.set(0, 0.58, 0.48);
      grp.add(gearbox);

      // Super Select Transfer Case
      const transfer = new THREE.Mesh(
        registerGeo(new THREE.BoxGeometry(0.38, 0.3, 0.34)),
        matAccent
      );
      transfer.position.set(-0.06, 0.55, 0.04);
      grp.add(transfer);

      // Rear Propeller Shaft
      const rearProp = new THREE.Mesh(
        registerGeo(new THREE.CylinderGeometry(0.042, 0.042, 1.48, 16)),
        matShaft
      );
      rearProp.rotation.x = Math.PI / 2;
      rearProp.position.set(0, 0.48, -0.78);
      grp.add(rearProp);

      // Front Propeller Shaft
      const frontProp = new THREE.Mesh(
        registerGeo(new THREE.CylinderGeometry(0.032, 0.032, 1.18, 14)),
        matShaft
      );
      frontProp.rotation.x = Math.PI / 2;
      frontProp.position.set(-0.18, 0.46, 0.78);
      grp.add(frontProp);

      // Rear Solid Axle Housing + Differential Pumpkin
      const rearAxle = new THREE.Mesh(
        registerGeo(new THREE.CylinderGeometry(0.055, 0.055, 1.56, 16)),
        matShaft
      );
      rearAxle.rotation.z = Math.PI / 2;
      rearAxle.position.set(0, 0.42, -1.48);
      grp.add(rearAxle);

      const rearDiff = new THREE.Mesh(
        registerGeo(new THREE.SphereGeometry(0.15, 20, 16)),
        matAccent
      );
      rearDiff.position.set(0, 0.42, -1.48);
      grp.add(rearDiff);

      // Front Differential Housing
      const frontDiff = new THREE.Mesh(
        registerGeo(new THREE.SphereGeometry(0.12, 16, 14)),
        matCase
      );
      frontDiff.position.set(-0.14, 0.44, 1.42);
      grp.add(frontDiff);

      tagGroup(grp, id, "ناقل الحركة والدفع الرباعي Super Select 4WD-II");
      vehicleRoot.add(grp);
      assemblies.set(id, {
        group: grp,
        basePos: new THREE.Vector3(0, 0, 0),
        explodeOffset: new THREE.Vector3(0, -0.58, 0),
        materials: [matCase, matShaft, matAccent],
      });
    }

    // --- ASSEMBLY 04: SUSPENSION (DOUBLE WISHBONE + REAR LEAF SPRINGS) ---
    {
      const id: AssemblyId = "suspension";
      const grp = new THREE.Group();
      const matArm = makeMat(
        { color: 0x1e293b, metalness: 0.7, roughness: 0.45 },
        id
      );
      const matSpring = makeMat(
        { color: 0x10b981, metalness: 0.55, roughness: 0.32 },
        id
      );
      const matLeaf = makeMat(
        { color: 0x475569, metalness: 0.78, roughness: 0.4 },
        id
      );

      // Front Double Wishbones + Coilovers
      const coilCurve = createHelixCurve(0.065, 0.34, 6, 48);
      const coilGeo = registerGeo(new THREE.TubeGeometry(coilCurve, 48, 0.013, 8, false));

      for (const side of [-1, 1]) {
        const lowerArm = new THREE.Mesh(
          registerGeo(new THREE.BoxGeometry(0.36, 0.045, 0.24)),
          matArm
        );
        lowerArm.position.set(side * 0.62, 0.38, 1.45);
        grp.add(lowerArm);

        const upperArm = new THREE.Mesh(
          registerGeo(new THREE.BoxGeometry(0.3, 0.035, 0.18)),
          matArm
        );
        upperArm.position.set(side * 0.58, 0.58, 1.45);
        grp.add(upperArm);

        const coil = new THREE.Mesh(coilGeo, matSpring);
        coil.position.set(side * 0.64, 0.58, 1.45);
        grp.add(coil);

        const shock = new THREE.Mesh(
          registerGeo(new THREE.CylinderGeometry(0.025, 0.025, 0.42, 12)),
          matLeaf
        );
        shock.position.set(side * 0.64, 0.58, 1.45);
        grp.add(shock);

        // Rear Semi-Elliptic Leaf Spring Pack (3 stacked blades)
        for (let b = 0; b < 3; b++) {
          const leaf = new THREE.Mesh(
            registerGeo(new THREE.BoxGeometry(0.07, 0.022, 1.15 - b * 0.18)),
            matLeaf
          );
          leaf.position.set(side * 0.54, 0.36 - b * 0.024, -1.48);
          grp.add(leaf);
        }

        // Rear Shock Absorber (angled)
        const rearShock = new THREE.Mesh(
          registerGeo(new THREE.CylinderGeometry(0.026, 0.026, 0.48, 12)),
          matSpring
        );
        rearShock.position.set(side * 0.48, 0.54, -1.36);
        rearShock.rotation.x = 0.32;
        grp.add(rearShock);
      }

      tagGroup(grp, id, "نظام التعليق (مقصات مزدوجة + سست ورقية)");
      vehicleRoot.add(grp);
      assemblies.set(id, {
        group: grp,
        basePos: new THREE.Vector3(0, 0, 0),
        explodeOffset: new THREE.Vector3(0, -0.45, 0),
        materials: [matArm, matSpring, matLeaf],
      });
    }

    // --- ASSEMBLY 05: BRAKES & STEERING ---
    {
      const id: AssemblyId = "brakes_steering";
      const grp = new THREE.Group();
      const matRotor = makeMat(
        { color: 0xcbd5e1, metalness: 0.92, roughness: 0.2 },
        id
      );
      const matCaliper = makeMat(
        { color: 0xdc2626, metalness: 0.5, roughness: 0.35 },
        id
      );
      const matRack = makeMat(
        { color: 0x64748b, metalness: 0.8, roughness: 0.35 },
        id
      );

      // Front Ventilated Discs & Calipers
      const rotorGeo = registerGeo(new THREE.CylinderGeometry(0.18, 0.18, 0.036, 24));
      const drumGeo = registerGeo(new THREE.CylinderGeometry(0.175, 0.175, 0.08, 24));

      for (const side of [-1, 1]) {
        const rotor = new THREE.Mesh(rotorGeo, matRotor);
        rotor.rotation.z = Math.PI / 2;
        rotor.position.set(side * 0.78, 0.42, 1.45);
        grp.add(rotor);

        const caliper = new THREE.Mesh(
          registerGeo(new THREE.BoxGeometry(0.08, 0.13, 0.09)),
          matCaliper
        );
        caliper.position.set(side * 0.78, 0.47, 1.56);
        grp.add(caliper);

        // Rear Drum Brakes
        const drum = new THREE.Mesh(drumGeo, matRack);
        drum.rotation.z = Math.PI / 2;
        drum.position.set(side * 0.78, 0.42, -1.48);
        grp.add(drum);
      }

      // Hydraulic Steering Rack & Tie Rods
      const rack = new THREE.Mesh(
        registerGeo(new THREE.CylinderGeometry(0.035, 0.035, 1.15, 14)),
        matRack
      );
      rack.rotation.z = Math.PI / 2;
      rack.position.set(0, 0.44, 1.25);
      grp.add(rack);

      const col = new THREE.Mesh(
        registerGeo(new THREE.CylinderGeometry(0.022, 0.022, 0.78, 12)),
        matRotor
      );
      col.position.set(-0.32, 0.85, 1.04);
      col.rotation.x = -0.78;
      grp.add(col);

      tagGroup(grp, id, "المكابح المهواة ودودة التوجيه الهيدروليكية");
      vehicleRoot.add(grp);
      assemblies.set(id, {
        group: grp,
        basePos: new THREE.Vector3(0, 0, 0),
        explodeOffset: new THREE.Vector3(0.45, -0.15, 0.35),
        materials: [matRotor, matCaliper, matRack],
      });
    }

    // --- ASSEMBLY 07: EXHAUST (DPF/EGR) & 75L FUEL TANK ---
    {
      const id: AssemblyId = "exhaust_fuel";
      const grp = new THREE.Group();
      const matPipe = makeMat(
        { color: 0x94a3b8, metalness: 0.85, roughness: 0.32 },
        id
      );
      const matTank = makeMat(
        { color: 0x4c1d95, metalness: 0.25, roughness: 0.55 },
        id
      );
      const matDpf = makeMat(
        { color: 0xa855f7, metalness: 0.7, roughness: 0.35 },
        id
      );

      // Exhaust Line
      const exhCurve = new THREE.CatmullRomCurve3([
        new THREE.Vector3(-0.32, 0.72, 1.25),
        new THREE.Vector3(-0.26, 0.42, 0.65),
        new THREE.Vector3(-0.24, 0.4, -0.3),
        new THREE.Vector3(-0.28, 0.44, -1.45),
        new THREE.Vector3(-0.32, 0.38, -2.25),
      ]);
      const exhPipe = new THREE.Mesh(
        registerGeo(new THREE.TubeGeometry(exhCurve, 36, 0.032, 10, false)),
        matPipe
      );
      grp.add(exhPipe);

      // DPF / Catalytic Canister
      const dpf = new THREE.Mesh(
        registerGeo(new THREE.CylinderGeometry(0.095, 0.095, 0.42, 18)),
        matDpf
      );
      dpf.rotation.x = Math.PI / 2;
      dpf.position.set(-0.25, 0.41, 0.25);
      grp.add(dpf);

      // 75L Fuel Tank
      const tank = new THREE.Mesh(
        registerGeo(new THREE.BoxGeometry(0.42, 0.22, 0.92)),
        matTank
      );
      tank.position.set(0.28, 0.44, -0.45);
      grp.add(tank);

      tagGroup(grp, id, "منظومة العادم (EGR/DPF) وخزان الوقود 75 لتر");
      vehicleRoot.add(grp);
      assemblies.set(id, {
        group: grp,
        basePos: new THREE.Vector3(0, 0, 0),
        explodeOffset: new THREE.Vector3(-0.65, -0.42, 0),
        materials: [matPipe, matTank, matDpf],
      });
    }

    // --- ASSEMBLY 08: DOUBLE CAB BODY, CARGO BED & 17" WHEELS ---
    {
      const id: AssemblyId = "body_wheels";
      const grp = new THREE.Group();
      const matBody = makeMat(
        { color: 0x94a3b8, metalness: 0.72, roughness: 0.28 },
        id
      );
      const matGlass = makeMat(
        {
          color: 0x0f172a,
          metalness: 0.15,
          roughness: 0.1,
          transparent: true,
          opacity: 0.55,
        },
        id
      );
      const matTrim = makeMat(
        { color: 0x1e293b, metalness: 0.3, roughness: 0.65 },
        id
      );
      const matChrome = makeMat(
        { color: 0xe2e8f0, metalness: 0.95, roughness: 0.12 },
        id
      );
      const matTire = makeMat(
        { color: 0x111827, metalness: 0.05, roughness: 0.85 },
        id
      );
      const matRim = makeMat(
        { color: 0xcbd5e1, metalness: 0.9, roughness: 0.22 },
        id
      );

      // Sculpted Double Cab Side Profile extruded along X
      const cabShape = new THREE.Shape();
      cabShape.moveTo(-0.08, 0.62);
      cabShape.lineTo(2.28, 0.62); // front bumper bottom
      cabShape.lineTo(2.34, 0.96); // grille face
      cabShape.lineTo(2.15, 1.18); // hood front
      cabShape.lineTo(1.25, 1.24); // hood cowl
      cabShape.lineTo(0.82, 1.72); // windshield A-pillar
      cabShape.lineTo(-0.04, 1.72); // roof rear
      cabShape.lineTo(-0.08, 0.62); // rear cab wall

      const cabGeo = registerGeo(
        new THREE.ExtrudeGeometry(cabShape, {
          depth: 1.56,
          bevelEnabled: true,
          bevelThickness: 0.06,
          bevelSize: 0.05,
          bevelSegments: 3,
        })
      );
      // Center along X and orient Z as forward (+Z)
      cabGeo.rotateY(-Math.PI / 2);
      cabGeo.translate(0.78, 0, 0);
      const cabMesh = new THREE.Mesh(cabGeo, matBody);
      grp.add(cabMesh);

      // Rear Cargo Bed (J-line signature pickup bed)
      const bedFloor = new THREE.Mesh(
        registerGeo(new THREE.BoxGeometry(1.56, 0.1, 1.56)),
        matTrim
      );
      bedFloor.position.set(0, 0.72, -1.46);
      grp.add(bedFloor);

      for (const side of [-0.74, 0.74]) {
        const bedSide = new THREE.Mesh(
          registerGeo(new THREE.BoxGeometry(0.1, 0.48, 1.56)),
          matBody
        );
        bedSide.position.set(side, 0.98, -1.46);
        grp.add(bedSide);
      }

      const tailgate = new THREE.Mesh(
        registerGeo(new THREE.BoxGeometry(1.56, 0.48, 0.09)),
        matBody
      );
      tailgate.position.set(0, 0.98, -2.2);
      grp.add(tailgate);

      // Windshield & Side Windows
      const windshield = new THREE.Mesh(
        registerGeo(new THREE.BoxGeometry(1.42, 0.56, 0.04)),
        matGlass
      );
      windshield.position.set(0, 1.46, 1.02);
      windshield.rotation.x = -0.68;
      grp.add(windshield);

      // Dynamic Chrome Front Grille & Headlights
      const grille = new THREE.Mesh(
        registerGeo(new THREE.BoxGeometry(0.96, 0.24, 0.06)),
        matChrome
      );
      grille.position.set(0, 1.02, 2.35);
      grp.add(grille);

      const hlGeo = registerGeo(new THREE.BoxGeometry(0.26, 0.14, 0.08));
      for (const side of [-0.62, 0.62]) {
        const hl = new THREE.Mesh(hlGeo, matChrome);
        hl.position.set(side, 1.04, 2.31);
        grp.add(hl);
      }

      // 4x 17-Inch Alloy Wheels & 245/65R17 All-Terrain Tires
      const tireGeo = registerGeo(new THREE.CylinderGeometry(0.375, 0.375, 0.25, 28));
      const rimGeo = registerGeo(new THREE.CylinderGeometry(0.22, 0.22, 0.26, 18));
      const wheelCoords: [number, number, number][] = [
        [-0.86, 0.38, 1.45],
        [0.86, 0.38, 1.45],
        [-0.86, 0.38, -1.48],
        [0.86, 0.38, -1.48],
      ];
      for (const [wx, wy, wz] of wheelCoords) {
        const wheelGroup = new THREE.Group();
        const tire = new THREE.Mesh(tireGeo, matTire);
        tire.rotation.z = Math.PI / 2;
        const rim = new THREE.Mesh(rimGeo, matRim);
        rim.rotation.z = Math.PI / 2;
        wheelGroup.add(tire, rim);
        wheelGroup.position.set(wx, wy, wz);
        grp.add(wheelGroup);
      }

      tagGroup(grp, id, "المقصورة المزدوجة (RISE) والصندوق والعجلات");
      vehicleRoot.add(grp);
      assemblies.set(id, {
        group: grp,
        basePos: new THREE.Vector3(0, 0, 0),
        explodeOffset: new THREE.Vector3(0, 1.45, 0),
        materials: [matBody, matGlass, matTrim, matChrome, matTire, matRim],
      });
    }

    // Pre-warm shaders on GPU
    if (!isSoftwareGl) {
      renderer.compile(scene, camera);
    }

    // 8. Coalesced On-Demand Rendering + Software WebGL Fence Pacing
    let frameId = 0;
    let renderBusy = false;
    let renderDirty = false;
    let currentExplode = explodeTargetRef.current;
    const clock = new THREE.Clock();

    function afterDraw(cb: () => void) {
      const gl = renderer.getContext() as WebGL2RenderingContext;
      const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
      gl.flush();
      const poll = () => {
        const state = sync && gl.getSyncParameter(sync, gl.SYNC_STATUS);
        if (state === gl.UNSIGNALED) {
          frameId = window.setTimeout(poll, 5);
        } else {
          if (sync) gl.deleteSync(sync);
          frameId = window.setTimeout(cb, 80);
        }
      };
      frameId = window.setTimeout(poll, 5);
    }

    function applyVisualStates(delta: number) {
      let animating = false;
      const targetExplode = explodeTargetRef.current;
      if (Math.abs(currentExplode - targetExplode) > 0.002) {
        currentExplode = THREE.MathUtils.damp(currentExplode, targetExplode, 6.5, delta);
        animating = true;
      } else {
        currentExplode = targetExplode;
      }

      const activeId = selectedIdRef.current;
      const isoId = isolatedRef.current;
      const useXray = xrayRef.current;

      assemblies.forEach((meta, id) => {
        _tmpVec.copy(meta.basePos).addScaledVector(meta.explodeOffset, currentExplode);
        meta.group.position.copy(_tmpVec);

        const isSelected = id === activeId;
        const isHiddenByIsolate = isoId !== null && isoId !== id;

        meta.group.visible = !isHiddenByIsolate;

        meta.materials.forEach((mat) => {
          const baseOp = mat.userData.baseOpacity ?? 1;
          if (id === "body_wheels" && useXray && isoId !== "body_wheels") {
            mat.transparent = true;
            mat.opacity = Math.min(baseOp, 0.22);
            mat.depthWrite = false;
          } else {
            mat.transparent = baseOp < 1;
            mat.opacity = baseOp;
            mat.depthWrite = baseOp >= 1;
          }

          if (isSelected) {
            mat.emissive.setHex(0x991b1b);
            mat.emissiveIntensity = 0.28;
          } else {
            mat.emissive.setHex(0x000000);
            mat.emissiveIntensity = 0;
          }
        });
      });

      // Smooth camera preset transition
      if (cameraGoalRef.current.active) {
        const distPos = camera.position.distanceTo(cameraGoalRef.current.pos);
        const distTgt = controls.target.distanceTo(cameraGoalRef.current.target);
        if (distPos > 0.02 || distTgt > 0.02) {
          camera.position.lerp(cameraGoalRef.current.pos, 1 - Math.exp(-5.5 * delta));
          controls.target.lerp(cameraGoalRef.current.target, 1 - Math.exp(-5.5 * delta));
          animating = true;
        } else {
          camera.position.copy(cameraGoalRef.current.pos);
          controls.target.copy(cameraGoalRef.current.target);
          cameraGoalRef.current.active = false;
        }
      }

      return animating;
    }

    function requestRender() {
      if (renderBusy) {
        renderDirty = true;
        return;
      }
      renderBusy = true;
      frameId = requestAnimationFrame(() => {
        renderDirty = false;
        const delta = Math.min(clock.getDelta(), 0.05);
        const needsMore = applyVisualStates(delta);
        const ctrlChanged = controls.update();
        renderer.render(scene, camera);

        const done = () => {
          renderBusy = false;
          if (renderDirty || needsMore || ctrlChanged) {
            requestRender();
          }
        };
        if (isSoftwareGl) afterDraw(done);
        else done();
      });
    }

    requestRenderRef.current = requestRender;
    controls.addEventListener("change", requestRender);

    // 9. Raycasting for Click Selection & Hover Tooltip
    const raycaster = new THREE.Raycaster();
    raycaster.layers.set(1);
    const pointer = new THREE.Vector2();
    let pointerDownPos = { x: 0, y: 0 };
    let lastHoverCheck = 0;

    const getHitAssembly = (clientX: number, clientY: number) => {
      const rect = renderer.domElement.getBoundingClientRect();
      pointer.x = ((clientX - rect.left) / rect.width) * 2 - 1;
      pointer.y = -((clientY - rect.top) / rect.height) * 2 + 1;
      raycaster.setFromCamera(pointer, camera);
      const visibleTargets = clickableMeshes.filter((m) => {
        let p: THREE.Object3D | null = m;
        while (p) {
          if (!p.visible) return false;
          p = p.parent;
        }
        return true;
      });
      const hits = raycaster.intersectObjects(visibleTargets, false);
      if (hits.length > 0) {
        const obj = hits[0].object;
        return {
          id: obj.userData.assemblyId as AssemblyId,
          label: obj.userData.labelAr as string,
        };
      }
      return null;
    };

    const onPointerDown = (e: PointerEvent) => {
      pointerDownPos = { x: e.clientX, y: e.clientY };
    };

    const onPointerUp = (e: PointerEvent) => {
      const dx = e.clientX - pointerDownPos.x;
      const dy = e.clientY - pointerDownPos.y;
      if (Math.hypot(dx, dy) > 6) return; // Ignore orbit drag
      const hit = getHitAssembly(e.clientX, e.clientY);
      if (hit) {
        onSelectRef.current(hit.id);
      }
    };

    const onPointerMove = (e: PointerEvent) => {
      const now = performance.now();
      if (now - lastHoverCheck < 50) return;
      lastHoverCheck = now;
      const hit = getHitAssembly(e.clientX, e.clientY);
      if (hit) {
        renderer.domElement.style.cursor = "pointer";
        setHoveredName(hit.label);
      } else {
        renderer.domElement.style.cursor = "grab";
        setHoveredName(null);
      }
    };

    renderer.domElement.addEventListener("pointerdown", onPointerDown);
    renderer.domElement.addEventListener("pointerup", onPointerUp);
    renderer.domElement.addEventListener("pointermove", onPointerMove);

    // 10. Context Lost / Resize
    const onContextLost = (e: Event) => {
      e.preventDefault();
      setContextLost(true);
    };
    const onContextRestored = () => {
      setContextLost(false);
      requestRender();
    };
    renderer.domElement.addEventListener("webglcontextlost", onContextLost);
    renderer.domElement.addEventListener("webglcontextrestored", onContextRestored);

    const resizeObserver = new ResizeObserver(() => {
      if (!container) return;
      const w = Math.max(container.clientWidth, 280);
      const h = Math.max(container.clientHeight, 280);
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
      requestRender();
    });
    resizeObserver.observe(container);

    // Initial render
    requestRender();

    return () => {
      cancelAnimationFrame(frameId);
      clearTimeout(frameId);
      resizeObserver.disconnect();
      controls.removeEventListener("start", onControlStart);
      controls.removeEventListener("change", requestRender);
      controls.dispose();
      renderer.domElement.removeEventListener("pointerdown", onPointerDown);
      renderer.domElement.removeEventListener("pointerup", onPointerUp);
      renderer.domElement.removeEventListener("pointermove", onPointerMove);
      renderer.domElement.removeEventListener("webglcontextlost", onContextLost);
      renderer.domElement.removeEventListener("webglcontextrestored", onContextRestored);
      disposableGeometries.forEach((g) => g.dispose());
      disposableMaterials.forEach((m) => m.dispose());
      gridTex.dispose();
      contactTex.dispose();
      envTexture.dispose();
      renderer.dispose();
      if (renderer.domElement.parentNode === container) {
        container.removeChild(renderer.domElement);
      }
    };
  }, []);

  const resetCamera = () => {
    cameraGoalRef.current.pos.set(4.6, 2.25, 4.35);
    cameraGoalRef.current.target.set(0, 0.72, 0);
    cameraGoalRef.current.active = true;
    requestRenderRef.current?.();
  };

  return (
    <div className="relative w-full h-full min-h-[360px] sm:min-h-[500px] bg-[#0B0F14] rounded-xl overflow-hidden border border-white/10">
      {/* Dedicated WebGL Mount */}
      <div ref={mountRef} className="w-full h-full touch-none" />

      {/* Context Lost Graceful Fallback */}
      {contextLost && (
        <div className="absolute inset-0 flex items-center justify-center bg-[#0B0F14]/95 text-slate-200 p-6 text-center">
          <div>
            <p className="text-base font-semibold mb-2">تم إيقاف سياق الرسوميات مؤقتاً</p>
            <p className="text-sm text-slate-400">جارٍ استعادة العرض ثلاثي الأبعاد...</p>
          </div>
        </div>
      )}

      {/* Clear Official White Logo Watermark (Top-Left of 3D Stage) */}
      <div className="pointer-events-none select-none absolute top-3 left-3 sm:top-4 sm:left-4 z-10">
        <img
          src="/assets/brand/logo_white.png"
          alt="علامة مائية للشعار الرسمي"
          referrerPolicy="no-referrer"
          className="w-14 h-14 sm:w-20 sm:h-20 object-contain opacity-85 drop-shadow-[0_2px_10px_rgba(0,0,0,0.75)]"
        />
      </div>

      {/* Top-Right Minimal Hover Readout (No backdrop-blur over WebGL) */}
      <div className="pointer-events-none absolute top-3 right-3 sm:top-4 sm:right-4 flex items-center gap-3 z-10 max-w-[62%]">
        <div className="bg-[#0D121A]/92 border border-white/10 px-3 py-1.5 sm:px-3.5 sm:py-2 rounded-lg text-[11px] sm:text-xs text-slate-200 truncate">
          <span className="text-slate-400">المنظومة: </span>
          <span className="font-semibold text-white">
            {hoveredName ??
              L200_ASSEMBLIES.find((a) => a.id === selectedAssemblyId)?.nameAr}
          </span>
        </div>
      </div>

      {/* Collapsible Bottom Control Dock (Zero backdrop-filter over WebGL) */}
      <div
        className="absolute bottom-4 left-1/2 -translate-x-1/2 z-10 flex flex-col items-center w-[min(780px,94%)]"
      >
        <button
          type="button"
          onClick={() => setDockCollapsed((c) => !c)}
          className="mb-1.5 inline-flex items-center gap-1.5 px-3 py-1 rounded-md bg-[#0D121A]/95 border border-white/12 text-[11px] font-medium text-slate-300 hover:text-white hover:border-white/25 transition-colors whitespace-nowrap shrink-0"
        >
          {dockCollapsed ? (
            <>
              <ChevronUp className="w-3.5 h-3.5" />
              <span>إظهار أدوات التحكم</span>
            </>
          ) : (
            <>
              <ChevronDown className="w-3.5 h-3.5" />
              <span>إخفاء اللوحة</span>
            </>
          )}
        </button>

        {!dockCollapsed && (
          <div className="w-full bg-[#0D121A]/95 border border-white/12 rounded-xl px-4 py-3 shadow-2xl flex flex-col gap-3">
            {/* Row 1: Exploded Slider + Primary Toggles */}
            <div className="flex flex-wrap items-center justify-between gap-4">
              <div className="flex items-center gap-3 flex-1 min-w-[220px]">
                <label
                  htmlFor="explode-range"
                  className="text-xs font-medium text-slate-300 whitespace-nowrap shrink-0"
                >
                  نسبة التفكيك:
                </label>
                <input
                  id="explode-range"
                  type="range"
                  min={0}
                  max={1}
                  step={0.01}
                  value={explodeFactor}
                  onChange={(e) => onExplodeChange(parseFloat(e.target.value))}
                  className="cad-slider w-full"
                />
                <span className="font-mono-tech text-xs text-red-400 w-10 text-left shrink-0">
                  {Math.round(explodeFactor * 100)}%
                </span>
              </div>

              <div className="flex items-center gap-2 shrink-0">
                <button
                  type="button"
                  onClick={() => setXrayBody((x) => !x)}
                  className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium border transition-colors whitespace-nowrap shrink-0 ${
                    xrayBody
                      ? "bg-sky-500/15 border-sky-400/40 text-sky-200"
                      : "bg-slate-800/70 border-white/10 text-slate-300 hover:text-white"
                  }`}
                >
                  {xrayBody ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
                  <span>{xrayBody ? "هيكل شفاف X-Ray" : "هيكل معتم"}</span>
                </button>

                <button
                  type="button"
                  onClick={() =>
                    onToggleIsolate(isolatedAssembly ? null : selectedAssemblyId)
                  }
                  className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium border transition-colors whitespace-nowrap shrink-0 ${
                    isolatedAssembly
                      ? "bg-amber-500/15 border-amber-400/40 text-amber-200"
                      : "bg-slate-800/70 border-white/10 text-slate-300 hover:text-white"
                  }`}
                >
                  <Layers className="w-3.5 h-3.5" />
                  <span>{isolatedAssembly ? "إلغاء العزل" : "عزل المنظومة"}</span>
                </button>

                <button
                  type="button"
                  onClick={resetCamera}
                  title="إعادة ضبط الكاميرا"
                  className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-medium bg-slate-800/70 border border-white/10 text-slate-300 hover:text-white transition-colors whitespace-nowrap shrink-0"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>ضبط المنظور</span>
                </button>
              </div>
            </div>

            {/* Row 2: Assembly Quick-Jump Buttons */}
            <div className="flex items-center gap-1.5 overflow-x-auto pb-0.5">
              {L200_ASSEMBLIES.map((asm) => {
                const active = asm.id === selectedAssemblyId;
                return (
                  <button
                    key={asm.id}
                    type="button"
                    onClick={() => {
                      onSelectAssembly(asm.id);
                      if (isolatedAssembly) onToggleIsolate(asm.id);
                      const found = L200_ASSEMBLIES.find((a) => a.id === asm.id);
                      if (found) {
                        cameraGoalRef.current.pos.set(...found.cameraPreset.position);
                        cameraGoalRef.current.target.set(...found.cameraPreset.target);
                        cameraGoalRef.current.active = true;
                        requestRenderRef.current?.();
                      }
                    }}
                    className={`px-2.5 py-1.5 rounded-md text-xs font-medium transition-colors whitespace-nowrap shrink-0 border ${
                      active
                        ? "bg-red-600 text-white border-red-500"
                        : "bg-slate-900/70 text-slate-300 border-white/8 hover:border-white/20 hover:text-white"
                    }`}
                  >
                    <span className="font-mono-tech opacity-75 ml-1">{asm.indexLabel}.</span>
                    <span>{asm.nameAr.split("(")[0].trim()}</span>
                  </button>
                );
              })}
              <button
                type="button"
                onClick={() => onExplodeChange(explodeFactor > 0.5 ? 0 : 1)}
                className="mr-auto inline-flex items-center gap-1 px-2.5 py-1.5 rounded-md text-xs font-medium bg-slate-800 text-slate-200 border border-white/15 hover:bg-slate-700 transition-colors whitespace-nowrap shrink-0"
              >
                <Maximize2 className="w-3 h-3" />
                <span>{explodeFactor > 0.5 ? "تجميع" : "تفكيك"}</span>
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
